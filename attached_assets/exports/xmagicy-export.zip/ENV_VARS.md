# Environment variables

No secrets are bundled in this export. The app needs a small set of
environment variables to run:

## Required for the frontend (Vite)

| Variable | Purpose | Example |
|----------|---------|---------|
| `PORT` | Port that the Vite dev server / preview server binds to. Vite throws if missing. | `3000` |
| `BASE_PATH` | Public URL prefix the app is served from. Becomes `base` in `vite.config.ts` and `BASE_URL` in the React Router. Must end with `/`. | `/` for a standalone deploy, or `/xmagicy/` if you keep it under a sub-path. |

## Optional for the frontend

| Variable | Purpose | Default |
|----------|---------|---------|
| `VITE_API_BASE_URL` | Override the backend base URL the contact form posts to. Read at build time. | `/api` |
| `NODE_ENV` | When `production`, disables Replit-only dev plugins (cartographer + dev banner). | unset |
| `REPL_ID` | Set automatically inside Replit. Only used to gate the Replit-only dev plugins. | unset |

## Required for the backend (only if you implement the contact endpoint)

| Variable | Purpose |
|----------|---------|
| `DATABASE_URL` | Postgres connection string used by `contact.route.ts` via `@workspace/db`. Format: `postgres://user:pass@host:5432/dbname?sslmode=require`. |

There is **no** API key, OAuth secret, or third-party integration in xMagicy.
No Stripe, no Clerk, no analytics, no SMTP. The whole app is HTML/CSS/JS plus
one POST to your own server.
