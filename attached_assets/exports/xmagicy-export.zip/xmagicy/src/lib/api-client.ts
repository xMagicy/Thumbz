import {
  useMutation,
  type UseMutationOptions,
  type UseMutationResult,
} from "@tanstack/react-query";

export type ContactBody = {
  name: string;
  email: string;
  message: string;
};

export type ContactResult = {
  id: number;
  createdAt: string;
};

export type ContactErrorResponse = {
  error: string;
};

export class ContactApiError extends Error {
  status: number;
  body: unknown;
  constructor(status: number, body: unknown, message?: string) {
    super(message ?? `Contact API error (${status})`);
    this.name = "ContactApiError";
    this.status = status;
    this.body = body;
  }
}

const API_BASE_URL =
  (import.meta as unknown as { env: { VITE_API_BASE_URL?: string } }).env
    .VITE_API_BASE_URL ?? "/api";

export async function submitContact(
  variables: { data: ContactBody },
  init?: RequestInit,
): Promise<ContactResult> {
  const res = await fetch(`${API_BASE_URL}/contact`, {
    method: "POST",
    headers: { "Content-Type": "application/json", ...(init?.headers ?? {}) },
    body: JSON.stringify(variables.data),
    ...init,
  });

  let payload: unknown = null;
  try {
    payload = await res.json();
  } catch {
    payload = null;
  }

  if (!res.ok) {
    const message =
      payload && typeof payload === "object" && "error" in payload
        ? String((payload as { error: unknown }).error)
        : `Request failed with ${res.status}`;
    throw new ContactApiError(res.status, payload, message);
  }

  return payload as ContactResult;
}

export function useSubmitContact(
  options?: UseMutationOptions<
    ContactResult,
    ContactApiError,
    { data: ContactBody }
  >,
): UseMutationResult<ContactResult, ContactApiError, { data: ContactBody }> {
  return useMutation({
    mutationKey: ["submitContact"],
    mutationFn: (variables) => submitContact(variables),
    ...options,
  });
}
