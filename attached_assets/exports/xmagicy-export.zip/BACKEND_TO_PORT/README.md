# Backend pieces to recreate in the new project

The xMagicy frontend calls **one** backend endpoint:

```
POST /api/contact   → records a contact submission
```

If you skip the backend, the contact form will fail silently. You have two paths:

## Option A — keep it simple (recommended for a portfolio site)

The standalone client at `xmagicy/src/lib/api-client.ts` (already wired into `Home.tsx`)
just `fetch`es `POST /api/contact` with `{ name, email, message }`. Stand up
**any** server that exposes that route and persists the row.

A minimal Express + Drizzle + Postgres setup is in this folder:

- `contact.route.ts` — original Express route handler (uses `req.log` from pino-http; replace with `console`/your logger if you don't use pino-http).
- `contactSubmissions.schema.ts` — original Drizzle schema using `drizzle-orm` + `drizzle-zod`.
- `contact_submissions.schema.sql` — raw `CREATE TABLE` SQL pulled from the live database. Run this once on your new project's DB to create the table.

To wire `contact.route.ts` in:
```ts
// in your server entry
import contactRouter from "./routes/contact";
app.use("/api/contact", contactRouter);
```

The route imports two workspace packages that don't exist in a standalone project:
- `@workspace/db` — replace with `import { db } from "./db"; import { contactSubmissionsTable } from "./schema/contactSubmissions";`
- `@workspace/api-zod` — replace `SubmitContactBody` with the Zod schema below, or with `insertContactSubmissionSchema` from `contactSubmissions.schema.ts`.

```ts
import { z } from "zod";
export const SubmitContactBody = z.object({
  name: z.string().min(1).max(200),
  email: z.string().email().min(3).max(254),
  message: z.string().min(1).max(4000),
});
```

## Option B — keep the contract-first OpenAPI codegen pipeline

If you want to keep the typed `useSubmitContact()` hook with auto-generated React Query bindings (Orval/oazapfts/etc.), use `openapi-contact-snippet.yaml` as the source-of-truth fragment. Re-run codegen to produce a typed client, then revert `xmagicy/src/lib/api-client.ts` and import `useSubmitContact` from your generated client like the original code did.

## Database table

Either run `contact_submissions.schema.sql`, or use Drizzle migrations off `contactSubmissions.schema.ts`.

Final table shape:

| column      | type                     | notes                       |
|-------------|--------------------------|-----------------------------|
| id          | serial primary key       |                             |
| name        | text not null            |                             |
| email       | text not null            |                             |
| message     | text not null            |                             |
| user_agent  | text nullable            | populated from request UA   |
| created_at  | timestamptz not null     | default now()               |

Index recommendation: `CREATE INDEX ON contact_submissions (created_at DESC);`
(not in the dump, but useful once you have a few hundred rows).
