# xMagicy — standalone export

This zip contains the xMagicy portfolio site, extracted from a pnpm monorepo and
re-packaged so it can run as its own Replit project (or any Node 20+ environment).

## Top-level layout

```
xmagicy-export/
├── README.md                ← you are here
├── ENV_VARS.md              ← environment variables the app needs
├── xmagicy/                 ← the actual app — drop this into a fresh repo as the project root
│   ├── package.json         ← standalone, all `catalog:` and `workspace:*` deps resolved
│   ├── tsconfig.json        ← standalone, no longer extends a parent
│   ├── vite.config.ts
│   ├── index.html
│   ├── components.json      ← shadcn config
│   ├── public/
│   │   ├── favicon.svg
│   │   └── opengraph.jpg
│   ├── .replit-artifact/
│   │   └── artifact.toml    ← Replit artifact metadata (only used inside Replit monorepos)
│   └── src/
│       ├── App.tsx, main.tsx, index.css
│       ├── assets/          ← avatar + 6 portfolio thumbs (PNG)
│       ├── components/ui/   ← full shadcn/ui component set
│       ├── hooks/           ← use-mobile, use-toast
│       ├── lib/
│       │   ├── utils.ts
│       │   └── api-client.ts  ← NEW. Drop-in replacement for the workspace `useSubmitContact` hook.
│       └── pages/
│           ├── Home.tsx     ← imports `useSubmitContact` from `@/lib/api-client` (was `@workspace/api-client-react`)
│           └── not-found.tsx
└── BACKEND_TO_PORT/
    ├── README.md            ← how to recreate the contact endpoint
    ├── contact.route.ts     ← the original Express route
    ├── contactSubmissions.schema.ts  ← original Drizzle schema
    ├── contact_submissions.schema.sql ← raw CREATE TABLE dump from live DB
    └── openapi-contact-snippet.yaml  ← OpenAPI fragment if you keep contract-first codegen
```

## Quick start in a fresh Replit project

1. Create a new Replit project (Node template).
2. Upload the contents of `xmagicy/` to the project root.
3. `pnpm install` (or `npm install` — there are no monorepo features being used anymore).
4. Set the env vars listed in `ENV_VARS.md` — at minimum `PORT` and `BASE_PATH`.
5. `pnpm dev` to verify, `pnpm build` for production.

Set `BASE_PATH=/` if this app sits at the domain root (most likely for a standalone deploy).
The original used `/xmagicy/` because it was mounted as a sub-path of a multi-artifact repo.

## What changed vs. the in-repo version

| File | Change |
|------|--------|
| `package.json` | All `"catalog:"` and `"workspace:*"` deps replaced with concrete versions. Added `typescript` (was inherited from monorepo root). |
| `tsconfig.json` | No longer `extends "../../tsconfig.base.json"` — settings are inlined. `references` to `../../lib/api-client-react` removed. |
| `src/lib/api-client.ts` | **New file.** Implements `useSubmitContact()` as a thin React Query mutation hitting `POST /api/contact`. Replaces `@workspace/api-client-react`. |
| `src/pages/Home.tsx` | One import line changed: `@workspace/api-client-react` → `@/lib/api-client`. Behavior is identical. |

## Mid-term cleanup

- The `vite.config.ts` still imports `@replit/vite-plugin-cartographer` and `@replit/vite-plugin-dev-banner` only when `REPL_ID` is set. Outside Replit they're no-ops. Safe to delete those two plugin imports if you're moving off Replit entirely.
- The `.replit-artifact/artifact.toml` is harmless outside the multi-artifact monorepo. Replit's normal `.replit` (and a workflow that runs `pnpm dev`) will be enough on its own.
- `@assets` alias in `vite.config.ts` points at `../../attached_assets` — a monorepo-shared assets folder. Nothing in `src/` actually imports from `@assets`, so you can delete that alias.

## Backend dependencies

xMagicy is mostly static. The only backend call is `POST /api/contact`. See
`BACKEND_TO_PORT/README.md` for how to recreate the endpoint and the
`contact_submissions` Postgres table.
